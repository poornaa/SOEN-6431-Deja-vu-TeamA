package hotelManagement;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class HotelLogic {
    private static final int ROOM_OPTION = 1;
    private static final int DATE_OPTION = 2;
    private Scanner input = new Scanner(System.in);
    public void viewRoom(ArrayList<Room> hotelRooms, ArrayList<Booking> bookings) {
        for (Room room : hotelRooms) {
            System.out.println("HOTEL ROOM: " + room.getRoomNumber());
            System.out.println("Amount of beds: " + room.getNumberOfBeds());
            System.out.println("Price per night: " + room.getPricePerNight());
            System.out.println("Balcony: " + (room.isHasBalcony() ? "Yes" : "No"));

            if (!room.getIsBooked().isEmpty()) {
                System.out.print("Booked during date(s): ");
                for (Booking booking : bookings) {
                    if (booking.getHotelRoomToBook() == (room.getRoomNumber() - 1)) {
                        System.out.print(booking.getDateToBook() + ", ");
                    }
                }
                System.out.println();
            } else {
                System.out.println("Booked during date(s): None");
            }

            System.out.println("Floor: " + room.getFloor());
            System.out.println();
        }
    }

    public ArrayList<Room> removeRoom(ArrayList<Room> hotelRooms, ArrayList<Booking> bookings) {
        viewRoom(hotelRooms, bookings);
        System.out.println("Which room would you like to remove?");
        int roomNumber = Integer.parseInt(input.nextLine());
        boolean roomExists = false;
        Iterator<Room> iterator = hotelRooms.iterator();

        while (iterator.hasNext()) {
            Room room = iterator.next();
            if (room.getRoomNumber() == roomNumber) {
                roomExists = true;
                if (room.getIsBooked().isEmpty()) {
                    iterator.remove(); // Use iterator to safely remove the room.
                    System.out.println("Room " + roomNumber + " has been removed successfully.");
                } else {
                    System.out.println("The room you wish to remove might already be booked.");
                }
                break;
            }
        }

        if (!roomExists) {
            System.out.println("Room " + roomNumber + " does not exist.");
        }

        return hotelRooms;
    }

    public ArrayList<Room> addRoom(ArrayList<Room> hotelRooms) {
        System.out.println("How many rooms would you like to add?");
        int numberOfRooms = readIntegerInput();

        for (int i = 0; i < numberOfRooms; i++) {
            System.out.println("How many beds does the room have? ");
            int amountOfBeds = readIntegerInput();

            System.out.println("Does the room have a balcony? (yes/no) ");
            boolean balcony = readBooleanInput();

            System.out.println("What is the price of the room? ");
            int pricePerNight = readIntegerInput();

            System.out.println("Which floor?");
            int floor = readIntegerInput();

            int roomNumber = hotelRooms.get(hotelRooms.size() - 1).getRoomNumber() + 1;
            Room room = new Room(roomNumber, amountOfBeds, balcony, pricePerNight, "", floor);
            hotelRooms.add(room);
        }

        return hotelRooms;
    }
    // Function to edit room info
    public ArrayList<Room> editRoom(ArrayList<Room> hotelRooms) {
        final int EDIT_ROOM_NUMBER = 1;
        final int EDIT_NUMBER_OF_BEDS = 2;
        final int EDIT_PRICE_PER_NIGHT = 3;
        final int EDIT_HAS_BALCONY = 4;
        final int EDIT_FLOOR = 5;

        boolean roomFound = false;
        int roomNumber;
        do {
            System.out.print("Enter the room number you want to edit: ");
            roomNumber = readIntegerInput();
            for (Room room : hotelRooms) {
                if (room.getRoomNumber() == roomNumber) {
                    roomFound = true;
                    break;
                }
            }
            if (!roomFound) {
                System.out.println("Room doesn't exist");
            }
        } while (!roomFound);

        PrintMenus.menuForEditRoomInfo();
        int answer = readIntegerInput();

        for (Room room : hotelRooms) {
            if (room.getRoomNumber() == roomNumber) {
                switch (answer) {
                    case EDIT_ROOM_NUMBER:
                        System.out.println("Which number would you like the room to get? ");
                        int newRoomNumber = readIntegerInput();
                        room.setRoomNumber(newRoomNumber);
                        break;
                    case EDIT_NUMBER_OF_BEDS:
                        System.out.println("How many beds are there in this room? ");
                        int newNumberOfBeds = readIntegerInput();
                        room.setNumberOfBeds(newNumberOfBeds);
                        break;
                    case EDIT_PRICE_PER_NIGHT:
                        System.out.println("What will the price per night be?");
                        int newPricePerNight = readIntegerInput();
                        room.setPricePerNight(newPricePerNight);
                        break;
                    case EDIT_HAS_BALCONY:
                        System.out.println("Does the room have a balcony? (yes/no) ");
                        String balconychoice = readStringInput();
                        boolean newHasBalcony = balconychoice.equalsIgnoreCase("yes");
                        room.setHasBalcony(newHasBalcony);
                        break;
                    case EDIT_FLOOR:
                        System.out.println("Which floor is the room located in? ");
                        int newFloor = readIntegerInput();
                        room.setFloor(newFloor);
                        break;
                    default:
                        System.out.println("Incorrect input, enter a number between 1-5 ");
                        break;
                }
                break;
            }
        }
        return hotelRooms;
    }

    public void searchBooking(ArrayList<Booking> bookings) {
        System.out.println("What date would you like to see bookings? ");
        String dateToSearchFor = input.nextLine();

        boolean printNoDate = true;

        System.out.println("Booking Details");
        System.out.println("=========================================================================");
        System.out.printf("%-15s %-15s %-15s %-15s%n", "Account", "Booked Date", "Room Booked", "Checked In");
        System.out.println("-------------------------------------------------------------------------");

        for (Booking booking : bookings) {
            if (booking.getDateToBook().equals(dateToSearchFor)) {
                printNoDate = false;
                int accountNumber = booking.getAccountNumber();
                String bookedDate = booking.getDateToBook();
                int roomBooked = booking.getHotelRoomToBook() + 1;
                String checkedIn = booking.isCheckedIn() ? "Yes" : "No";

                System.out.printf("%-15d %-15s %-15d %-15s%n", accountNumber, bookedDate, roomBooked, checkedIn);
            }
        }

        System.out.println("=========================================================================");
        if (printNoDate) {
            System.out.println("No bookings during this date..");
        }
    }


    public ArrayList<Customer> addOneCustomerToArrayList(ArrayList<Customer> arrayListCustomer) {
        Customer customer = new Customer("1993-03-25-1234", "Josefin Johansson", "Stockholm", "0123456789",
                "Josefin.93@hotmail.com");
        arrayListCustomer.add(customer);
        return arrayListCustomer;
    }

    public ArrayList<Room> createArrayListOfRooms(ArrayList<Room> hotelRooms) {
        final int FLOOR_1_START = 1;
        final int FLOOR_1_END = 3;
        final int FLOOR_2_START = 4;
        final int FLOOR_2_END = 6;
        final int FLOOR_3_START = 7;
        final int FLOOR_3_END = 9;

        final int FLOOR_1_CAPACITY = 2000;
        final int FLOOR_2_CAPACITY = 2500;
        final int FLOOR_3_CAPACITY = 2700;

        // Floor 1
        for (int i = FLOOR_1_START; i <= FLOOR_1_END; i++) {
            Room room = new Room(i, 1, false, FLOOR_1_CAPACITY, "", i);
            hotelRooms.add(room);
        }

        // Floor 2
        for (int i = FLOOR_2_START; i <= FLOOR_2_END; i++) {
            Room room = new Room(i, 2, true, FLOOR_2_CAPACITY, "", i);
            hotelRooms.add(room);
        }

        // Floor 3
        for (int i = FLOOR_3_START; i <= FLOOR_3_END; i++) {
            Room room = new Room(i, 2, true, FLOOR_3_CAPACITY, "", i);
            hotelRooms.add(room);
        }

        return hotelRooms;
    }



    public ArrayList<Customer> addCustomer(ArrayList<Customer> arraylistcustomer) {
        final String PHONE_REGEX = "0\\d{9}";

        String ssn = "";
        String phone = "";

        do {
            System.out.println("Account number: " + (Customer.getNumberCounter() + 1));
            System.out.print("Name: ");
            String name = input.nextLine();


            while (true) {
                System.out.print("SSN (yyyy-mm-dd-xxxx): ");
                ssn = input.nextLine();
                // Check if SSN already exists
                boolean ssnExists = false;
                for (Customer customer : arraylistcustomer) {
                    if (customer.getSsn().equals(ssn)) {
                        System.out.println("This SSN is already existing");
                        ssnExists = true;
                        break;
                    }
                }
                if (!ssnExists) {
                    break;
                }
            }



            System.out.print("Email: ");
            String email = input.nextLine();
            System.out.print("Address: ");
            String address = input.nextLine();

            // Validate Phone number
            while (true) {
                System.out.print("Phone number: ");
                phone = input.nextLine();
                if (!phone.matches(PHONE_REGEX)) {
                    System.out.println("Phone number has to be 10 digits and start with a 0..");
                } else {
                    break;
                }
            }

            Customer customer = new Customer(ssn, name, address, phone, email);
            arraylistcustomer.add(customer);

            // Continue adding customers or not
            System.out.print("Do you want to add another customer? (yes/no): ");
            String response = input.nextLine();
            if (!response.equalsIgnoreCase("yes")) {
                break;
            }

        } while (true);

        return arraylistcustomer;
    }


    public void viewCustomer(ArrayList<Customer> arraylistcustomer) {
        for (int i = 0; i < arraylistcustomer.size(); i++) {
            System.out.println("Account number: " + arraylistcustomer.get(i).getAccountNumber());
            System.out.println("Name: " + arraylistcustomer.get(i).getName());
            System.out.println("Social security number: " + arraylistcustomer.get(i).getSsn());
            System.out.println("Email: " + arraylistcustomer.get(i).getEmail());
            System.out.println("Address: " + arraylistcustomer.get(i).getAddress());
            System.out.println("Phone number: " + arraylistcustomer.get(i).getTelephoneNumber());
            System.out.println();
        }
    }

    public ArrayList<Customer> removeCustomer(ArrayList<Customer> arraylistcustomer, ArrayList<Booking> bookings) {
        System.out.println("Enter account number of the person to remove: ");
        int accountNumber = Integer.parseInt(input.nextLine());
        boolean hasActiveBooking = false;

        for (Booking booking : bookings) {
            if (booking.getAccountNumber() == accountNumber && booking.isCheckedIn()) {
                hasActiveBooking = true;
                break;
            }
        }

        if (hasActiveBooking) {
            System.out.println("Not possible to remove this customer since the customer has an active booking.");
        } else {
            arraylistcustomer.removeIf(customer -> customer.getAccountNumber() == accountNumber);
        }

        return arraylistcustomer;
    }


    public int readIntegerInput() {
        while (true) {
            try {
                return Integer.parseInt(input.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid integer.");
            }
        }
    }
    // Validating boolean input
    public boolean readBooleanInput() {
        while (true) {
            String response = input.nextLine().trim().toLowerCase();
            if (response.equals("yes")) {
                return true;
            } else if (response.equals("no")) {
                return false;
            } else {
                System.out.println("Invalid input. Please enter 'yes' or 'no'.");
            }
        }
    }

    public ArrayList<Booking> makeBooking(ArrayList<Booking> bookings, ArrayList<Customer> arrayListCustomer, ArrayList<Room> hotelRooms) {
        boolean validAccountNumber = false;
        boolean validDateToBook = false;
        boolean validRoomToBook = false;

        int roomToBook;
        int accountNumber;
        String dateToBook;

        do {
            do {
                System.out.println("Enter your account number: ");
                accountNumber = readIntegerInput();
                validAccountNumber = accountNumber > 0;

                if (!validAccountNumber) {
                    System.out.println("Please type in an account number greater than 0.");
                }
            } while (!validAccountNumber);

            do {
                System.out.println("Which date would you like to book? (yyyy-mm-dd) ");
                dateToBook = input.nextLine();
                validDateToBook = dateToBook.matches("\\d{4}-\\d{2}-\\d{2}");

                if (!validDateToBook) {
                    System.out.println("Please type in the date format yyyy-mm-dd.");
                }
            } while (!validDateToBook);

            do {
                viewRoom(hotelRooms, bookings);
                System.out.println("Which room would you like to book? ");
                roomToBook = readIntegerInput() - 1;
                validRoomToBook = roomToBook >= 0 && roomToBook < hotelRooms.size();

                if (!validRoomToBook) {
                    System.out.println("Please choose a valid room number.");
                } else {
                    Room selectedRoom = hotelRooms.get(roomToBook);
                    if (!selectedRoom.getIsBooked().contains(dateToBook)) {
                        selectedRoom.bookRoom(dateToBook);
                        validRoomToBook = true;
                    } else {
                        System.out.println("This room is already booked on this date.");
                        validRoomToBook = false;
                    }
                }
            } while (!validRoomToBook);

            Booking booking = new Booking(roomToBook, dateToBook, accountNumber, false);
            bookings.add(booking);

            System.out.println("Booking successfully made!");

            System.out.println("Do you want to make another booking? (yes/no)");
            String continueBooking = readStringInput();
            if (!continueBooking.equalsIgnoreCase("yes")) {
                break;
            }
        } while (true);

        return bookings;
    }
    public String readStringInput() {
        while (true) {
            String inputString = input.nextLine().trim();
            if (!inputString.isEmpty()) {
                return inputString;
            } else {
                System.out.println("Invalid input. Please enter a non-empty string.");
            }
        }
    }

    public void viewInfoAboutCustomer(ArrayList<Customer> arrayListCustomer, ArrayList<Booking> bookings, ArrayList<Booking> previousBookings) {
        System.out.println("Enter Account number you would like to see info about: ");
        int accountNumber = readIntegerInput();
        System.out.println("Customer information");

        boolean customerFound = false;
        for (Customer customer : arrayListCustomer) {
            if (customer.getAccountNumber() == accountNumber) {
                System.out.println("Account number: " + customer.getAccountNumber());
                System.out.println("Name: " + customer.getName());
                System.out.println("SSN: " + customer.getSsn());
                System.out.println("Address: " + customer.getAddress());
                System.out.println("Phone number: " + customer.getTelephoneNumber());
                System.out.println("Email: " + customer.getEmail());
                customerFound = true;
                break;
            }
        }
        if (!customerFound) {
            System.out.println("Customer with the given account number not found.");
        }

        System.out.println("\nCURRENT BOOKING(S)");
        for (Booking booking : bookings) {
            if (booking.getAccountNumber() == accountNumber) {
                System.out.println("Account number: " + booking.getAccountNumber());
                System.out.println("Hotel room booked: " + (booking.getHotelRoomToBook() + 1));
                System.out.println("Booked during date: " + booking.getDateToBook());
                System.out.println("Checked in: " + (booking.isCheckedIn() ? "yes" : "no"));
            }
        }

        System.out.println("\nPREVIOUS BOOKING(S)");
        for (Booking previousBooking : previousBookings) {
            if (previousBooking.getAccountNumber() == accountNumber) {
                System.out.println("Account number: " + previousBooking.getAccountNumber());
                System.out.println("Room that was booked: " + (previousBooking.getHotelRoomToBook() + 1));
                System.out.println("Was booked the date: " + previousBooking.getDateToBook());
            }
        }
        System.out.println();
    }


    public ArrayList<Customer> editCustomInfo(ArrayList<Customer> customerArrayList) {
        final int EDIT_NAME = 1;
        final int EDIT_ADDRESS = 2;
        final int EDIT_PHONE_NUMBER = 3;
        final int EDIT_EMAIL = 4;

        System.out.println("Enter account number of the customer you wish to edit..");
        int accountinput = readIntegerInput();

        Customer customerToEdit = findCustomerByAccountNumber(customerArrayList, accountinput);
        if (customerToEdit == null) {
            System.out.println("Seems like this account number does not exist..");
            return customerArrayList;
        }

        displayEditOptions();
        int choice = readIntegerInput();
        switch (choice) {
            case EDIT_NAME:
                editCustomerName(customerToEdit);
                break;
            case EDIT_ADDRESS:
                editCustomerAddress(customerToEdit);
                break;
            case EDIT_PHONE_NUMBER:
                editCustomerPhoneNumber(customerToEdit);
                break;
            case EDIT_EMAIL:
                editCustomerEmail(customerToEdit);
                break;
            default:
                System.out.println("Invalid choice!");
                break;
        }
        return customerArrayList;
    }

     public Customer findCustomerByAccountNumber(ArrayList<Customer> customerArrayList, int accountNumber) {
        for (Customer customer : customerArrayList) {
            if (customer.getAccountNumber() == accountNumber) {
                return customer;
            }
        }
        return null;
    }

    public void displayEditOptions() {
        System.out.print("Which of the following information would you like to change? \n" +
                "1) name \n" +
                "2) address \n" +
                "3) phonenumber \n" +
                "4) email \n");
    }

    private void editCustomerName(Customer customer) {
        System.out.println("Current name: " + customer.getName());
        System.out.print("New name: ");
        String newname = readStringInput();
        customer.setName(newname);
    }

    private void editCustomerAddress(Customer customer) {
        System.out.println("Current address: " + customer.getAddress());
        System.out.print("New address: ");
        String newaddress = readStringInput();
        customer.setAddress(newaddress);
    }

    private void editCustomerPhoneNumber(Customer customer) {
        System.out.println("Current phonenumber: " + customer.getTelephoneNumber());
        System.out.print("New phonenumber: ");
        String newphonenumber = readStringInput();
        customer.setTelephoneNumber(newphonenumber);
    }

    private void editCustomerEmail(Customer customer) {
        System.out.println("Current email: " + customer.getEmail());
        System.out.print("New email: ");
        String newemail = readStringInput();
        customer.setEmail(newemail);
    }


    public ArrayList<Booking> editBookingInfo(ArrayList<Booking> bookings, ArrayList<Room> hotelRooms, ArrayList<Customer> customers) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your account number: ");
        int accountNumber = Integer.parseInt(scanner.nextLine());

        boolean printError = printCustomerBookings(bookings, customers, accountNumber);

        if (printError) {
            System.out.println("The account number you entered might not have a booking or it does not exist");
            return bookings;
        }

        int bookingToEdit = getBookingToEdit(bookings, scanner, accountNumber);
        if (bookingToEdit == -1) {
            return bookings;
        }

        editBookingInformation(bookings, hotelRooms, scanner, bookingToEdit);

        return bookings;
    }

    private boolean printCustomerBookings(ArrayList<Booking> bookings, ArrayList<Customer> customers, int accountNumber) {
        boolean printError = true;
        for (Customer customer : customers) {
            if (customer.getAccountNumber() == accountNumber) {
                for (int j = 0; j < bookings.size(); j++) {
                    if (bookings.get(j).getAccountNumber() == accountNumber) {
                        if (printError) {
                            System.out.println("Your bookings: ");
                            printError = false;
                        }
                        System.out.println("[" + (j + 1) + "] " + "(date) " + bookings.get(j).getDateToBook() + " (room) " + (bookings.get(j).getHotelRoomToBook() + 1));
                    }
                }
            }
        }
        return printError;
    }

    private int getBookingToEdit(ArrayList<Booking> bookings, Scanner scanner, int accountNumber) {
        System.out.println("Which booking would you like to edit? ");
        int bookingToEdit = (Integer.parseInt(scanner.nextLine()) - 1);
        for (int i = 0; i < bookings.size(); i++) {
            if (bookings.get(bookingToEdit).getAccountNumber() != accountNumber) {
                System.out.println("You cannot edit bookings that do not belong to your account.");
                return -1;
            }
        }
        return bookingToEdit;
    }

    private void editBookingInformation(ArrayList<Booking> bookings, ArrayList<Room> hotelRooms, Scanner scanner, int bookingToEdit) {
        System.out.println("What info would you like to edit?");
        System.out.println("[" + ROOM_OPTION + "] room");
        System.out.println("[" + DATE_OPTION + "] date");
        int decision = Integer.parseInt(scanner.nextLine());

        if (decision == ROOM_OPTION) {
            System.out.print("Current room: " + (bookings.get(bookingToEdit).getHotelRoomToBook() + 1) + "\n");
            System.out.println("What room would you like to change to? ");
            int newRoom = (Integer.parseInt(scanner.nextLine()) - 1);
            if (hotelRooms.get(newRoom).getIsBooked().contains(bookings.get(bookingToEdit).getDateToBook())) {
                System.out.println("The room you wish to book is already booked this date..");
            } else {
                updateRoomInformation(bookings, hotelRooms, bookingToEdit, newRoom);
            }
        } else if (decision == DATE_OPTION) {
            System.out.print("Current date: " + bookings.get(bookingToEdit).getDateToBook() + "\n");
            System.out.println("What date would you like to change to? ");
            String newDate = scanner.nextLine();
            if (!newDate.matches("[0-9]+[0-9]+[0-9]+[0-9]+[-]+[0-9]+[0-9]+[-]+[0-9]+[0-9]")) {
                System.out.println("Please type in format yyyy-mm-dd");
            } else {
                updateDateInformation(bookings, hotelRooms, bookingToEdit, newDate);
            }
        }
    }

    private void updateRoomInformation(ArrayList<Booking> bookings, ArrayList<Room> hotelRooms, int bookingToEdit, int newRoom) {
        int counter = 0;
        do {
            if (hotelRooms.get(counter).getIsBooked().contains(bookings.get(bookingToEdit).getDateToBook())) {
                String newIsBooked = hotelRooms.get(counter).getIsBooked().replace(bookings.get(bookingToEdit).getDateToBook() + ", ", "");
                hotelRooms.get(counter).setIsBooked(newIsBooked);
                break;
            } else if (counter >= hotelRooms.size()) {
                break;
            } else {
                counter++;
            }
        } while (counter < hotelRooms.size());

        hotelRooms.get(newRoom).setIsBooked(bookings.get(bookingToEdit).getDateToBook());
        bookings.get(bookingToEdit).setHotelRoomToBook(newRoom);
    }

    private void updateDateInformation(ArrayList<Booking> bookings, ArrayList<Room> hotelRooms, int bookingToEdit, String newDate) {
        int counter = 0;
        do {
            if (hotelRooms.get(counter).getIsBooked().contains(newDate)) {
                System.out.println("The date you wish to change to is already taken..");
            } else {
                int counter2 = 0;
                do {
                    if (hotelRooms.get(counter2).getIsBooked().contains(bookings.get(bookingToEdit).getDateToBook()) && (bookings.get(bookingToEdit).getHotelRoomToBook() + 1) == hotelRooms.get(counter2).getRoomNumber()) {
                        String newIsBooked = hotelRooms.get(counter2).getIsBooked().replace(bookings.get(bookingToEdit).getDateToBook() + ", ", newDate + ", ");
                        hotelRooms.get(counter2).setIsBooked(newIsBooked);
                        break;
                    } else if (counter2 >= hotelRooms.size()) {
                        break;
                    } else {
                        counter2++;
                    }
                } while (counter2 < hotelRooms.size());
                bookings.get(bookingToEdit).setDateToBook(newDate);
                break;
            }
            counter++;
        } while (counter < hotelRooms.size());
    }


    public void availableRooms(ArrayList<Room> hotelrooms) {
        boolean validDate = false;

        while (!validDate) {
            System.out.println("Which date would you like to see available rooms? ");
            String date = readStringInput();

            if (!date.matches("[0-9]+[0-9]+[0-9]+[0-9]+[-]+[0-9]+[0-9]+[-]+[0-9]+[0-9]")) {
                System.out.println("Date has to be in yyyy-mm-dd format..");
            } else {
                validDate = true;
                boolean foundAvailableRoom = false;
                for (Room room : hotelrooms) {
                    if (!room.getIsBooked().contains(date)) {
                        System.out.println("Room: " + room.getRoomNumber());
                        foundAvailableRoom = true;
                    }
                }
                if (!foundAvailableRoom) {
                    System.out.println("No available rooms for the selected date.");
                }
            }
        }
    }

    public void checkIn(ArrayList<Booking> bookings, ArrayList<Customer> customerArrayList) {
        System.out.println("Enter your account number!");
        int accountNumber = readIntegerInput();

        boolean foundAccount = findCustomerAccount(customerArrayList, accountNumber);
        if (!foundAccount) {
            System.out.println("Seems like the account number you have entered does not exist, or it does not have any bookings.\n");
            return;
        }

        boolean foundBookingToCheckIn = showBookingsToCheckIn(bookings, accountNumber);
        if (!foundBookingToCheckIn) {
            System.out.println("No bookings available for check-in.");
            return;
        }

        int bookingToCheckIn = getBookingChoice(bookings);
        if (bookingToCheckIn == -1) {
            System.out.println("Invalid booking choice!");
            return;
        }

        checkInBooking(bookings, bookingToCheckIn);
    }



    private boolean showBookingsToCheckIn(ArrayList<Booking> bookings, int accountNumber) {
        boolean foundBookingToCheckIn = false;
        for (Booking booking : bookings) {
            if (booking.getAccountNumber() == accountNumber && !booking.isCheckedIn()) {
                if (!foundBookingToCheckIn) {
                    System.out.println("Which booking would you like to check in? ");
                    foundBookingToCheckIn = true;
                }
                System.out.println("[" + (bookings.indexOf(booking) + 1) + "] " + "(date) " + booking.getDateToBook() + " (room) " + (booking.getHotelRoomToBook() + 1));
            }
        }
        return foundBookingToCheckIn;
    }

    private int getBookingChoice(ArrayList<Booking> bookings) {
        int bookingToCheckIn = readIntegerInput();
        if (bookingToCheckIn >= 1 && bookingToCheckIn <= bookings.size() && !bookings.get(bookingToCheckIn - 1).isCheckedIn()) {
            return bookingToCheckIn;
        }
        return -1;
    }

    private void checkInBooking(ArrayList<Booking> bookings, int bookingToCheckIn) {
        bookings.get(bookingToCheckIn - 1).setCheckedIn(true);
    }

    public void checkOut(ArrayList<Booking> bookings, ArrayList<Customer> customerArrayList, ArrayList<Booking> previousBookings, ArrayList<Room> hotelRooms) {
        System.out.println("Enter your account number!");
        int accountNumber = readIntegerInput();

        boolean foundAccount = findCustomerAccount(customerArrayList, accountNumber);
        if (!foundAccount) {
            System.out.println("Seems like the account number you have entered does not exist, or it does not have any bookings.\n");
            return;
        }

        boolean foundBookingToCheckOut = showBookingsToCheckOut(bookings, accountNumber);

        if (!foundBookingToCheckOut) {
            System.out.println("No bookings available for check-out.");
            return;
        }

        int bookingToCheckOut = getBookingChoice(bookings, accountNumber);
        if (bookingToCheckOut == -1) {
            System.out.println("Invalid booking choice!");
            return;
        }

        performCheckOut(bookings, previousBookings, hotelRooms, bookingToCheckOut);
    }

    private boolean findCustomerAccount(ArrayList<Customer> customerArrayList, int accountNumber) {
        for (Customer customer : customerArrayList) {
            if (customer.getAccountNumber() == accountNumber) {
                return true;
            }
        }
        return false;
    }

    private boolean showBookingsToCheckOut(ArrayList<Booking> bookings, int accountNumber) {
        boolean foundBookingToCheckOut = false;
        for (Booking booking : bookings) {
            if (booking.getAccountNumber() == accountNumber && booking.isCheckedIn()) {
                if (!foundBookingToCheckOut) {
                    System.out.println("Which booking would you like to check out? ");
                    foundBookingToCheckOut = true;
                }
                System.out.println("[" + (bookings.indexOf(booking) + 1) + "] " + "(date) " + booking.getDateToBook() + " (room) " + (booking.getHotelRoomToBook() + 1));
            }
        }
        return foundBookingToCheckOut;
    }

    private int getBookingChoice(ArrayList<Booking> bookings, int accountNumber) {
        int bookingToCheckOut = readIntegerInput();
        if (bookingToCheckOut >= 0 && bookingToCheckOut < bookings.size() && bookings.get(bookingToCheckOut).getAccountNumber() == accountNumber) {
            return bookingToCheckOut;
        }
        return -1;
    }

    private void performCheckOut(ArrayList<Booking> bookings, ArrayList<Booking> previousBookings, ArrayList<Room> hotelRooms, int bookingToCheckOut) {
        int hotelRoomToCheckOut = bookings.get(bookingToCheckOut).getHotelRoomToBook();
        String dateToCheckOut = bookings.get(bookingToCheckOut).getDateToBook();

        // Remove the booking from the room's "isBooked" list
        String isBooked = hotelRooms.get(hotelRoomToCheckOut).getIsBooked();
        isBooked = isBooked.replace(dateToCheckOut + ", ", "");
        hotelRooms.get(hotelRoomToCheckOut).setIsBooked(isBooked);

        // Move the booking to previousBookings
        previousBookings.add(bookings.get(bookingToCheckOut));
        bookings.remove(bookingToCheckOut);
    }

    public void viewCurrentBookings(ArrayList<Booking> bookings) {
        if (!bookings.isEmpty()) {
            for (Booking booking : bookings) {
                System.out.println("Booking belongs to account: " + booking.getAccountNumber());
                System.out.println("Booked date: " + booking.getDateToBook());
                System.out.println("Room booked: " + (booking.getHotelRoomToBook() + 1));
                System.out.println("Checked in: " + (booking.isCheckedIn() ? "yes" : "no"));
                System.out.println();
            }
        } else {
            System.out.println("No current bookings available");
        }
    }

    public void viewCurrentBookingsSpecificCustomer(ArrayList<Booking> bookings) {
        System.out.println("Enter account you would like to see bookings for: ");
        int accountNumber = readIntegerInput();
        boolean bookingOrNot = true;

        if (!bookings.isEmpty()) {
            for (Booking booking : bookings) {
                if (booking.getAccountNumber() == accountNumber) {
                    System.out.println("Account number: " + booking.getAccountNumber());
                    System.out.println("Booked date: " + booking.getDateToBook());
                    System.out.println("Room booked: " + (booking.getHotelRoomToBook() + 1));
                    System.out.println("Checked in: " + (booking.isCheckedIn() ? "yes" : "no"));
                    System.out.println();
                    bookingOrNot = false;
                }
            }
        }
        if (bookingOrNot) {
            System.out.println("Seems like the account number you have entered does not exist, or it does not have any bookings.\n ");
        }
    }

    public void viewPreviousBookingsForSpecificCustomer(ArrayList<Booking> previousBookings) {
        System.out.println("Enter account you would like to see previous bookings for: ");
        int accountNumber = readIntegerInput();
        boolean bookingOrNot = true;

        if (!previousBookings.isEmpty()) {
            for (Booking booking : previousBookings) {
                if (booking.getAccountNumber() == accountNumber) {
                    System.out.println("Account number: " + booking.getAccountNumber());
                    System.out.println("Booked date: " + booking.getDateToBook());
                    System.out.println("Room that was booked: " + (booking.getHotelRoomToBook() + 1));
                    System.out.println();
                    bookingOrNot = false;
                }
            }
        }
        if (bookingOrNot) {
            System.out.println("Seems like the account number you have entered does not exist, or it does not have any bookings.\n ");
        }
    }

    public ArrayList<Booking> removeBooking(ArrayList<Booking> bookings, ArrayList<Customer> arraylistCustomer, ArrayList<Room> hotelRooms, ArrayList<Booking> previousBookings) {
        System.out.println("Enter account number: ");
        int accountNumber = readIntegerInput();

        boolean foundAccount = findCustomerAccount(arraylistCustomer, accountNumber);
        if (!foundAccount) {
            System.out.println("Seems like the account number you have entered does not exist.\n");
            return bookings;
        }

        boolean foundBooking = showBookingsForRemoval(bookings, accountNumber);
        if (!foundBooking) {
            System.out.println("Seems like the account number you have entered does not have any bookings.\n");
            return bookings;
        }

        int bookingToRemove = getBookingChoice(bookings, accountNumber);
        if (bookingToRemove == -1) {
            System.out.println("Invalid booking choice!");
            return bookings;
        }

        performBookingRemoval(bookings, hotelRooms, previousBookings, bookingToRemove);
        return bookings;
    }

    private boolean showBookingsForRemoval(ArrayList<Booking> bookings, int accountNumber) {
        boolean foundBooking = false;
        for (Booking booking : bookings) {
            if (booking.getAccountNumber() == accountNumber) {
                System.out.println("[" + (bookings.indexOf(booking) + 1) + "] " + "(date) " + booking.getDateToBook() + "(room) " + (booking.getHotelRoomToBook() + 1));
                foundBooking = true;
            }
        }
        return foundBooking;
    }

    private void performBookingRemoval(ArrayList<Booking> bookings, ArrayList<Room> hotelRooms, ArrayList<Booking> previousBookings, int bookingToRemove) {
        int hotelRoomToCheckOut = bookings.get(bookingToRemove).getHotelRoomToBook();
        String dateToCheckOut = bookings.get(bookingToRemove).getDateToBook();

        // Remove the booking from the room's "isBooked" list
        String isBooked = hotelRooms.get(hotelRoomToCheckOut).getIsBooked();
        isBooked = isBooked.replace(dateToCheckOut + ", ", "");
        hotelRooms.get(hotelRoomToCheckOut).setIsBooked(isBooked);

        // Move the booking to previousBookings
        previousBookings.add(bookings.get(bookingToRemove));
        bookings.remove(bookingToRemove);
    }
}