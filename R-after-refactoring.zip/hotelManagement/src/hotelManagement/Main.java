package hotelManagement;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    private static Scanner input = new Scanner(System.in);

    // Constants for menu options
    private static final int MM_EMPLOYEE = 1;
    private static final int MM_EXIT = 2;

    // Constants for employee menu options
    private static final int EM_CUSTOMERS = 1;
    private static final int EM_ROOMS = 2;
    private static final int EM_BOOKINGS = 3;
    private static final int EM_BACK = 4;

    // Constants for customer menu options
    private static final int CM_VIEW_CUSTOMERS = 1;
    private static final int CM_ADD_CUSTOMER = 2;
    private static final int CM_REMOVE_CUSTOMER = 3;
    private static final int CM_EDIT_CUSTOMER = 4;
    private static final int CM_CURRENT_BOOKINGS = 5;
    private static final int CM_PREVIOUS_BOOKINGS = 6;
    private static final int CM_CUSTOMER_INFO = 7;
    private static final int CM_BACK = 8;

    // Constants for room menu options
    private static final int RM_VIEW_ROOMS = 1;
    private static final int RM_AVAILABLE_ROOMS = 2;
    private static final int RM_OPTION_ADD_ROOM = 3;
    private static final int RM_REMOVE_ROOM = 4;
    private static final int RM_EDIT_ROOM = 5;
    private static final int RM_BACK = 6;

    // Constants for booking menu options
    private static final int BM_PREVIOUS_BOOKINGS = 1;
    private static final int BM_CURRENT_BOOKINGS = 2;
    private static final int BM_MAKE_BOOKING = 3;
    private static final int BM_REMOVE_BOOKING = 4;
    private static final int BM_SEARCH_BOOKING = 5;
    private static final int BM_EDIT_BOOKING = 6;
    private static final int BM_CHECK_IN = 7;
    private static final int BM_CHECK_OUT = 8;
    private static final int BM_BACK = 9;

    public static void main(String[] args) throws IOException {
        Main main = new Main();
        main.runHotelManagementSystem();
    }
    private static int readIntInput() {
        int answer = 0;
        boolean validInput = false;

        while (!validInput) {
            try {
                System.out.print("Enter an integer: ");
                answer = Integer.parseInt(input.nextLine());
                validInput = true;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid integer.");
            }
        }

        return answer;
    }

    public void runHotelManagementSystem() throws IOException {
        // Initialize variables
        ArrayList<Customer> arrayListCustomer = new ArrayList<>();
        ArrayList<Room> hotelRooms = new ArrayList<>();
        ArrayList<Booking> bookings = new ArrayList<>();
        ArrayList<Booking> previousBookings = new ArrayList<>();
        HotelLogic hotelLogic = new HotelLogic();
        CreateFile createFile = new CreateFile();
        ReadFile readFile = new ReadFile();

        // Create rooms and add a customer
        hotelRooms = hotelLogic.createArrayListOfRooms(hotelRooms);
        arrayListCustomer = hotelLogic.addOneCustomerToArrayList(arrayListCustomer);

        // Main menu loop
        boolean exitProgram = false;
        do {
            PrintMenus.printMenu();
            int answer = readIntInput();

            switch (answer) {
                case MM_EMPLOYEE:
                    handleEmployeeMenu(hotelLogic, arrayListCustomer, hotelRooms, bookings, previousBookings);
                    break;
                case MM_EXIT:
                    PrintMenus.printByeMessage();
                    exitProgram = true;
                    break;
                default:
                    System.out.println("Incorrect input..");
            }
        } while (!exitProgram);
    }
    // Function to take input for the employee menu
    private void handleEmployeeMenu(HotelLogic hotelLogic, ArrayList<Customer> arrayListCustomer, ArrayList<Room> hotelRooms,
                                    ArrayList<Booking> bookings, ArrayList<Booking> previousBookings) throws IOException {
        boolean backToMainMenu = false;

        while (!backToMainMenu) {
            PrintMenus.viewMenuEmployeer1();
            int choice1 = readIntInput();

            switch (choice1) {
                case EM_CUSTOMERS:
                    handleCustomerMenu(hotelLogic, arrayListCustomer, bookings, previousBookings);
                    break;
                case EM_ROOMS:
                    handleRoomMenu(hotelLogic, hotelRooms, bookings);
                    break;
                case EM_BOOKINGS:
                    handleBookingMenu(hotelLogic, bookings, arrayListCustomer, hotelRooms, previousBookings);
                    break;
                case EM_BACK:
                    backToMainMenu = true;
                    break;
                default:
                    System.out.println("Incorrect input..");
            }
        }
    }
    // Function to take input for the customer menu
    private void handleCustomerMenu(HotelLogic hotelLogic, ArrayList<Customer> arrayListCustomer,
                                    ArrayList<Booking> bookings, ArrayList<Booking> previousBookings) {
        boolean backToEmployeeMenu = false;

        while (!backToEmployeeMenu) {
            PrintMenus.viewMenuEmployerOption1();
            int choice2 = readIntInput();

            switch (choice2) {
                case CM_VIEW_CUSTOMERS:
                    hotelLogic.viewCustomer(arrayListCustomer);
                    break;
                case CM_ADD_CUSTOMER:
                    arrayListCustomer = hotelLogic.addCustomer(arrayListCustomer);
                    break;
                case CM_REMOVE_CUSTOMER:
                    arrayListCustomer = hotelLogic.removeCustomer(arrayListCustomer, bookings);
                    break;
                case CM_EDIT_CUSTOMER:
                    arrayListCustomer = hotelLogic.editCustomInfo(arrayListCustomer);
                    break;
                case CM_CURRENT_BOOKINGS:
                    hotelLogic.viewCurrentBookingsSpecificCustomer(bookings);
                    break;
                case CM_PREVIOUS_BOOKINGS:
                    hotelLogic.viewPreviousBookingsForSpecificCustomer(previousBookings);
                    break;
                case CM_CUSTOMER_INFO:
                    hotelLogic.viewInfoAboutCustomer(arrayListCustomer, bookings, previousBookings);
                    break;
                case CM_BACK:
                    backToEmployeeMenu = true;
                    break;
                default:
                    System.out.println("Incorrect input..");
            }
        }
    }
    // Function to take input for the room menu
    public void handleRoomMenu(HotelLogic hotelLogic, ArrayList<Room> hotelRooms, ArrayList<Booking> bookings) {
        boolean backToEmployeeMenu = false;

        while (!backToEmployeeMenu) {
            PrintMenus.viewMenuEmployerOption2();
            int choice4 = readIntInput();

            switch (choice4) {
                case RM_VIEW_ROOMS:
                    hotelLogic.viewRoom(hotelRooms, bookings);
                    break;
                case RM_AVAILABLE_ROOMS:
                    hotelLogic.availableRooms(hotelRooms);
                    break;
                case RM_OPTION_ADD_ROOM:
                    hotelRooms = hotelLogic.addRoom(hotelRooms);
                    break;
                case RM_REMOVE_ROOM:
                    hotelRooms = hotelLogic.removeRoom(hotelRooms, bookings);
                    break;
                case RM_EDIT_ROOM:
                    hotelRooms = hotelLogic.editRoom(hotelRooms);
                    break;
                case RM_BACK:
                    backToEmployeeMenu = true;
                    break;
                default:
                    System.out.println("Incorrect input..");
            }
        }
    }
    // Function to take input for the booking menu
    private void handleBookingMenu(HotelLogic hotelLogic, ArrayList<Booking> bookings, ArrayList<Customer> arrayListCustomer,
                                   ArrayList<Room> hotelRooms, ArrayList<Booking> previousBookings) throws IOException {
        boolean backToEmployeeMenu = false;

        while (!backToEmployeeMenu) {
            PrintMenus.viewMenuEmployerOption3();
            int choice2 = readIntInput();

            switch (choice2) {
                case BM_PREVIOUS_BOOKINGS:
                    ReadFile readFile = new ReadFile();
                    readFile.openFile();
                    readFile.readFile();
                    readFile.closeFile();
                    break;
                case BM_CURRENT_BOOKINGS:
                    hotelLogic.viewCurrentBookings(bookings);
                    break;
                case BM_MAKE_BOOKING:
                    bookings = hotelLogic.makeBooking(bookings, arrayListCustomer, hotelRooms);
                    CreateFile.openFile();
                    CreateFile.addRecord(bookings.get(bookings.size() - 1));
                    CreateFile.closeFile();
                    break;
                case BM_REMOVE_BOOKING:
                    hotelLogic.removeBooking(bookings, arrayListCustomer, hotelRooms, previousBookings);
                    break;
                case BM_SEARCH_BOOKING:
                    hotelLogic.searchBooking(bookings);
                    break;
                case BM_EDIT_BOOKING:
                    hotelLogic.editBookingInfo(bookings, hotelRooms, arrayListCustomer);
                    break;
                case BM_CHECK_IN:
                    hotelLogic.checkIn(bookings, arrayListCustomer);
                    break;
                case BM_CHECK_OUT:
                    hotelLogic.checkOut(bookings, arrayListCustomer, previousBookings, hotelRooms);
                    break;
                case BM_BACK:
                    backToEmployeeMenu = true;
                    break;
                default:
                    System.out.println("Incorrect input..");
            }
        }
    }
}
