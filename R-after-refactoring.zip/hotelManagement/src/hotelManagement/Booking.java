package hotelManagement;

public class Booking {

    private int hotelRoomToBook;
    private String dateToBook;
    private int accountNumber;
    private boolean checkedIn;

    public Booking(int hotelRoomToBook, String dateToBook, int accountNumber, boolean checkedIn) {
        this.hotelRoomToBook = hotelRoomToBook;
        this.dateToBook = dateToBook;
        this.accountNumber = accountNumber;
        this.checkedIn = checkedIn;
    }

    // Constructors
    public Booking() {
        // Default constructor (no-argument)
    }

    // Getters and Setters
    public int getHotelRoomToBook() {
        return hotelRoomToBook;
    }

    public void setHotelRoomToBook(int hotelRoomToBook) {
        this.hotelRoomToBook = hotelRoomToBook;
    }

    public String getDateToBook() {
        return dateToBook;
    }

    public void setDateToBook(String dateToBook) {
        this.dateToBook = dateToBook;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public boolean isCheckedIn() {
        return checkedIn;
    }

    public void setCheckedIn(boolean checkedIn) {
        this.checkedIn = checkedIn;
    }

    // Other methods if needed
}
