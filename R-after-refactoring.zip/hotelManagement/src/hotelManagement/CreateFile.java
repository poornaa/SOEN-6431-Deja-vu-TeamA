package hotelManagement;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.format.DateTimeFormatter;

public class CreateFile {

    private static BufferedWriter bufferedWriter;

    public static void openFile() throws IOException {
        try {
            Path path = Paths.get("allBookings.txt");
            bufferedWriter = Files.newBufferedWriter(path, StandardOpenOption.APPEND);
        } catch (IOException ex) {
            System.out.println("There was an error while opening the file..");
            throw ex; // Rethrow the exception to handle it at the higher level if needed
        }
    }

    public static void addRecord(Booking booking) throws IOException {
        try {
            int accountNumber = booking.getAccountNumber();
            int roomBooked = booking.getHotelRoomToBook() + 1;
            String dateToBook = booking.getDateToBook();



            // Now use the formattedDate in the String.format() call
            String formattedRecord = String.format("Account number: %d, Room booked: %d, Booked the date: %s%n",
                    accountNumber, roomBooked, dateToBook);
            bufferedWriter.write(formattedRecord);
        } catch (IOException ex) {
            System.out.println("There was an error while writing to the file..");
            throw ex; // Rethrow the exception to handle it at the higher level if needed
        }
    }


    public static void closeFile() throws IOException {
        try {
            bufferedWriter.close();
        } catch (IOException ex) {
            System.out.println("There was an error while closing the file..");
            throw ex; // Rethrow the exception to handle it at the higher level if needed
        }
    }
}
