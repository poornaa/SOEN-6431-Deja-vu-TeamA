package hotelManagement;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadFile {

    private Scanner x;

    public void openFile() {
        try {
            x = new Scanner(new File("allBookings.txt"));
        } catch (FileNotFoundException ex) {
            System.out.println("There was an error opening the file to read..");
        }
    }

    public void readFile() {
        try {
            while (x.hasNext()) {
                System.out.print(x.nextLine() + "\n");
            }
        } catch (Exception ex) {
            System.out.println("There was an error reading the file..");
        } finally {
            closeFile(); // Close the file regardless of whether an exception occurred or not.
        }
    }

    public void closeFile() {
        if (x != null) {
            x.close();
        }
    }
}
