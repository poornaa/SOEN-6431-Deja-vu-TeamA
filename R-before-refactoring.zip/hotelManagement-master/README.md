# **HOTEL MANAGEMENT APPLICATION**


This is a console application that allows the users to manage and book hotel rooms.
The system can be used either by the consumers or employees.
Created att Kristianstad university by 4 first year students.
